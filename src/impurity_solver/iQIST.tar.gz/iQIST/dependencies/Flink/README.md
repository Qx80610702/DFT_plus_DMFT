# Flink

The *Flink* library is a collection of Fortran modules and subroutines for scientific computing.

## Version

v1.0.5-devel.210802

## License

GNU General Public License Version 3

## Documentation

The reference guide is placed in the `docs` folder.
