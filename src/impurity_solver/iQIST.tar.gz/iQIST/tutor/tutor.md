# iQIST (Interacting Quantum Impurity Solver Toolkit)

## t011: how to use the narcissus code?

Ref.: Phys. Rev. Lett. 97, 076405 (2006)

## t121: how to use the manjushaka and jasmine codes?

Ref.: Phys. Rev. B 74, 155107 (2006)
