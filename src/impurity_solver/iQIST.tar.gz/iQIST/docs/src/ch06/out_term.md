### Terminal output

**Introduction**

From the terminal output, we can monitor the running status of the atomic eigenvalue problem solver. It is not important.

**Format**

N/A

**Code**

N/A