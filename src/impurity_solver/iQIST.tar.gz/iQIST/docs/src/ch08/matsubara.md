### Matsubara Green's function and self-energy function

