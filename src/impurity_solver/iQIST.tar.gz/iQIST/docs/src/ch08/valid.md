## Code validation

