### Two-particle Green's function and vertex function

