### Retarded interaction and dynamical screening effect

