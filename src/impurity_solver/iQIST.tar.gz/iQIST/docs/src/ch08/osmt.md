### Orbital-selective Mott transition in two-band Hubbard model

