### Analytical continuation for Matsubara self-energy function

