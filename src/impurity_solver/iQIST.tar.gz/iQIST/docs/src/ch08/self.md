### One-shot and self-consistent calculations

