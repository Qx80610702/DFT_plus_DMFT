## Practical exercises

* [Orbital-selective Mott transition in two-band Hubbard model](osmt.md)
* [Orbital Kondo and spin Kondo effects in three-band Anderson impurity model](kondo.md)