### Data binning mode

