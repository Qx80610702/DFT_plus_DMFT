### Spin-spin correlation function and orbital-orbital correlation function

