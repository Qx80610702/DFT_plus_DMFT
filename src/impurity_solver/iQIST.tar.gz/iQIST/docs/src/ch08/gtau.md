### Imaginary-time Green's function

