### Crystal field splitting

