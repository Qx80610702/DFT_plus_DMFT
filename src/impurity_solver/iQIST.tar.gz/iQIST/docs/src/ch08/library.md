## Library mode

* Call iQIST from Fortran language
* Call iQIST from Python language