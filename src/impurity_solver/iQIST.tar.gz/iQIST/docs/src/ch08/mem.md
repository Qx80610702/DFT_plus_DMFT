### Analytical continuation for imaginary-time Green's function

