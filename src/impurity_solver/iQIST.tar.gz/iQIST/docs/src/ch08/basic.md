## Basic applications

Well, are you newbie to the iQIST software package? 

Don't worry! 

In this section, we will help you to be familiar with it step by step. The examples shown in this section are very simple. It is easy to finish them within a few hours under normal conditions. Now please start your computer, and let's go!

* [Hello iQIST!](hello.md)
* [Mott metal-insulator transition](mott.md)