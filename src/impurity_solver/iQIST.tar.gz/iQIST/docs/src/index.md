![header image](figure/logo.png)

```@raw html
<h1>
Reference Manual <font face = 'times'><i>for</i></font> <br/> <font color = 'purple'>I</font>nteracting <font color = 'orange'>Q</font>uantum <font color = 'orange'>I</font>mpurity <font color = 'orange'>S</font>olver <font color = 'orange'>T</font>oolkit
</h1>
```

Draft Version January 20, 2017 (in progress)

Written by:

**Li Huang**, **Yilin Wang**, **Haiyan Lu**, **Liang Du**, and **Zi Yang Meng**

```text
Obi-Wan Kenobi: 

    1. Use the Manual, Luke! (To Luke Skywalker)

    2. May the Manual be with you. (To Anakin Skywalker)
```