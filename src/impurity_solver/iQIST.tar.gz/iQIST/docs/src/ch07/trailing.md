### script/d_trailing.sh

**Introduction**

The purpose of this script is to remove the trailing white spaces in the given file.

**Type**

Bash shell script

**Usage**

You have to supply the file name to this script, like this:

```
$ ./d_trailing.sh file_name
```

**Input**

N/A

**Output**

See the terminal output.

**Comment**

!!! note

    This script is used by the iQIST Developer Team *internally*.