### script/d_clean.py

**Introduction**

The purpose of this script is to clean the dull *.DS\_Store* files for the Mac OS X filesystem.

**Type**

Python script

**Usage**

You have to specify the folder/directory name in which you want to clean the *.DS\_Store* files, like this:

```
$ ./d_clean.py /home/my/iqist
```

**Input**

N/A

**Output**

N/A

**Comment**

!!! note

    This script is used by the iQIST Developer Team *internally*.