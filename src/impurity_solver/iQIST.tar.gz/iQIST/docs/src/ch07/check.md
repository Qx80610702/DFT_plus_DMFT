### script/d_check.py

**Introduction**

It can be used to check whether the lines in a given file are ended with blanks.

**Type**

Python script

**Usage**

You have to specify the file name, like this:

```
$ ./d_check.py ctqmc_dmft.f90
```

**Input**

N/A

**Output**

See the terminal output.

**Comment**

!!! note

    This script is used by the iQIST Developer Team *internally*.