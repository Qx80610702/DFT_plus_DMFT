```
   o         o__ __o       __o__     o__ __o    ____o__ __o____ 
 _<|>_      /v     v\        |      /v     v\    /   \   /   \  
           />       <\      / \    />       <\        \o/       
   o     o/           \o    \o/   _\o____              |        
  <|>   <|             |>    |         \_\__o__       < >       
  / \    \\           //    < >              \         |        
  \o/      \       \o/       |     \         /         o        
   |        o       |        o      o       o         <|        
  / \       <\__   / \     __|>_    <\__ __/>         / \
```

Copyright 2016 by **The iQIST Developer Team**

*Permission is granted to copy, distribute and/or modify the documentation under the terms of the GNU Free Documentation License, Version 1.2 or any later version published by the Free Software Foundation; with no Invariant Sections, no Front-Cover Texts, and no Back-Cover Texts.*

*Permission is granted to copy, distribute and/or modify the code of the package under the terms of the GNU Public License, Version 2 or any later version published by the Free Software Foundation.*