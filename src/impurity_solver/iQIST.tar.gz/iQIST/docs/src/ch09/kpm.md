### Kernel polynomial method

