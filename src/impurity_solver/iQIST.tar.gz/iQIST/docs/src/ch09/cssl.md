### Common service subroutine library

**s_error.f90**

**s_fft.f90**

**s_integrator.f90**

**s_matrix.f90**

**s_spline.f90**

**s_util.f90**

**s_vector.f90**