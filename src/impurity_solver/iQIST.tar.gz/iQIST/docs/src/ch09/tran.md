### Transition probability

