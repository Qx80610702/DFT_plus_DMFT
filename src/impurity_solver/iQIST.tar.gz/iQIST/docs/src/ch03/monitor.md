## Monitor the codes

The quantum impurity solvers in the iQIST software package will generate a lot of terminal output and data files (such as *solver.hist.dat*, *solver.status.dat*, *solver.nmat.dat*, etc.) at run time. Through them you can judge the status of the solvers.

See

* [Standard output files](../ch04/output.md) // Output stuffs for CT-HYB/HF-QMC impurity solvers.

for more details.